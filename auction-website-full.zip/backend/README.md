Backend quick notes:
- Run `npm install` then `npm run dev`
- Visit `http://localhost:4000/api/ping` to check server
- A seeded user exists: email: user@example.com password: password
