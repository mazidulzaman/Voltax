const productService = require('../services/productService');

exports.list = async (req, res, next) => {
  try {
    const items = productService.list();
    res.json(items);
  } catch (e) { next(e); }
};

exports.getById = async (req, res, next) => {
  try {
    const p = productService.getById(req.params.id);
    if (!p) return res.status(404).json({ message: 'Not found' });
    res.json(p);
  } catch (e) { next(e); }
};
