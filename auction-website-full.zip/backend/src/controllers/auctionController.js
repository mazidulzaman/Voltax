const auctionService = require('../services/auctionService');

exports.list = (req, res, next) => {
  try {
    res.json(auctionService.list());
  } catch (e) { next(e); }
};

exports.getById = (req, res, next) => {
  try {
    const a = auctionService.getById(req.params.id);
    if (!a) return res.status(404).json({ message: 'Not found' });
    res.json(a);
  } catch (e) { next(e); }
};

exports.placeBid = (req, res, next) => {
  try {
    const user = req.user;
    const amount = Number(req.body.amount);
    if (!amount) return res.status(400).json({ message: 'amount required' });
    const updated = auctionService.placeBid(req.params.id, user.sub, amount);
    res.json(updated);
  } catch (e) { next(e); }
};
