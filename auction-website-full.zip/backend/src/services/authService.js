const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const users = []; // in-memory users: { id, email, passwordHash, role }

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret';
const TOKEN_EXPIRES = process.env.TOKEN_EXPIRES_IN || '7d';

exports.register = async ({ email, password }) => {
  if (!email || !password) throw { status: 400, message: 'email & password required' };
  const exists = users.find(u => u.email === email);
  if (exists) throw { status: 400, message: 'User already exists' };
  const hash = await bcrypt.hash(password, 10);
  const user = { id: uuidv4(), email, passwordHash: hash, role: 'user' };
  users.push(user);
  return user;
};

exports.login = async ({ email, password }) => {
  const user = users.find(u => u.email === email);
  if (!user) throw { status: 401, message: 'Invalid credentials' };
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) throw { status: 401, message: 'Invalid credentials' };
  const token = jwt.sign({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: TOKEN_EXPIRES });
  return token;
};

// helper for controllers
exports.getUserById = (id) => users.find(u => u.id === id);

// Pre-seed a test user for convenience in development
(async () => {
  const pw = 'password';
  const hash = await bcrypt.hash(pw, 10);
  users.push({ id: 'test-user-1', email: 'user@example.com', passwordHash: hash, role: 'user' });
})();
