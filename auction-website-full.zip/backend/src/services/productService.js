const { v4: uuidv4 } = require('uuid');

const products = [
  { id: 'p1', name: 'Vintage Camera', description: 'Old camera', startingPrice: 1500 },
  { id: 'p2', name: 'Desk Lamp', description: 'LED lamp', startingPrice: 499 }
];

exports.list = () => products;
exports.getById = (id) => products.find(p => p.id === id);

// helper to add product later
exports.add = (p) => {
  const product = { id: uuidv4(), ...p };
  products.push(product);
  return product;
};
