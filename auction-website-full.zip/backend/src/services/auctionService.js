const { v4: uuidv4 } = require('uuid');

// sample auctions in-memory
const auctions = [
  {
    id: 'a1',
    productId: 'p1',
    title: 'Vintage Camera Auction',
    description: 'A classic camera up for auction.',
    startTime: Date.now(),
    endTime: Date.now() + 1000 * 60 * 60, // +1h
    startingPrice: 1500,
    currentBid: 1500,
    highestBidder: null,
    bids: [] // {id, bidderId, amount, time}
  },
  {
    id: 'a2',
    productId: 'p2',
    title: 'Desk Lamp Auction',
    description: 'Bright lamp',
    startTime: Date.now(),
    endTime: Date.now() + 1000 * 60 * 30, // +30m
    startingPrice: 499,
    currentBid: 499,
    highestBidder: null,
    bids: []
  }
];

exports.list = () => auctions;

exports.getById = (id) => auctions.find(a => a.id === id);

exports.placeBid = (auctionId, bidderId, amount) => {
  const auction = auctions.find(a => a.id === auctionId);
  if (!auction) throw { status: 404, message: 'Auction not found' };
  const now = Date.now();
  if (now < auction.startTime) throw { status: 400, message: 'Auction not started' };
  if (now > auction.endTime) throw { status: 400, message: 'Auction ended' };
  if (amount <= auction.currentBid) throw { status: 400, message: 'Bid must be higher than current bid' };

  const bid = { id: uuidv4(), bidderId, amount, time: Date.now() };
  auction.bids.push(bid);
  auction.currentBid = amount;
  auction.highestBidder = bidderId;

  // extend auction by small amount if bid near end (anti-sniping)
  const extendWindow = 60 * 1000; // 1 min
  if (auction.endTime - now < 30 * 1000) {
    auction.endTime += extendWindow;
  }

  return auction;
};
