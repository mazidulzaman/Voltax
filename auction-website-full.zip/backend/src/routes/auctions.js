const express = require('express');
const router = express.Router();
const auctionController = require('../controllers/auctionController');
const auth = require('../middleware/authMiddleware');

router.get('/', auctionController.list);
router.get('/:id', auctionController.getById);
router.post('/:id/bid', auth, auctionController.placeBid);

module.exports = router;
