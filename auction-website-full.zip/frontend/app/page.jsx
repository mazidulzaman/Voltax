import Link from 'next/link';
import { useEffect, useState } from 'react';
import api from '../lib/api';

export default function Home() {
  const [auctions, setAuctions] = useState([]);

  useEffect(() => {
    api.get('/auctions').then(res => setAuctions(res.data)).catch(console.error);
  }, []);

  return (
    <div>
      <h1>Live Auctions</h1>
      {auctions.length === 0 && <p>No auctions yet.</p>}
      <ul>
        {auctions.map(a => (
          <li key={a.id}>
            <Link href={`/auctions/${a.id}`}>{a.title}</Link> — currentBid: ₹{a.currentBid}
          </li>
        ))}
      </ul>
      <p><Link href="/products">Products</Link></p>
    </div>
  );
}
