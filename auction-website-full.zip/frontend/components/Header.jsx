'use client';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import jwtDecode from 'jwt-decode';

export default function Header() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const t = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
    if (t) {
      try {
        const u = jwtDecode(t);
        setUser(u);
      } catch { setUser(null); }
    }
  }, []);

  const logout = () => {
    if (typeof window !== 'undefined') localStorage.removeItem('token');
    window.location.href = '/';
  };

  return (
    <header style={{ display: 'flex', gap: 12, padding: 12, borderBottom: '1px solid #ddd' }}>
      <Link href="/"><strong>Auction</strong></Link>
      <Link href="/products">Products</Link>
      <Link href="/">Auctions</Link>
      <div style={{ marginLeft: 'auto' }}>
        {user ? (
          <>
            <span style={{ marginRight: 8 }}>{user.email}</span>
            <button onClick={logout}>Logout</button>
          </>
        ) : (
          <Link href="/(auth)/login">Login</Link>
        )}
      </div>
    </header>
  );
}
