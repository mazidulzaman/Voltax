Frontend quick notes:
- Run `npm install` then `npm run dev`
- Ensure NEXT_PUBLIC_API_BASE points to backend (http://localhost:4000/api)
