# Auction Website (Full Starter)

This bundle contains a minimal but functional starter for an auction website:
- `frontend/` — Next.js app (App Router) running on port 3000
- `backend/`  — Express API server running on port 4000

## Quick start (development)

### Backend
cd backend
npm install
# create .env from .env.example
npm run dev

### Frontend
cd frontend
npm install
# create .env.local from .env.local.example
npm run dev

Open http://localhost:3000 (frontend) and backend runs on http://localhost:4000
