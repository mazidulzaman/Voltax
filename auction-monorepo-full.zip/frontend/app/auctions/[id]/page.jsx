'use client';
import { useEffect, useState } from 'react';
import api from '../../../lib/api';
import { useParams } from 'next/navigation';

export default function AuctionPage() {
  const params = useParams();
  const id = params.id;
  const [auction, setAuction] = useState(null);
  const [bid, setBid] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => {
    api.get(`/auctions/${id}`).then(res => setAuction(res.data)).catch(console.error);
  }, [id]);

  const placeBid = async () => {
    setMsg('');
    const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
    try {
      const res = await api.post(`/auctions/${id}/bid`, { amount: Number(bid) }, {
        headers: { Authorization: token ? `Bearer ${token}` : '' }
      });
      setAuction(res.data);
      setMsg('Bid placed!');
    } catch (e) {
      setMsg(e?.response?.data?.message || 'Bid failed');
    }
  };

  if (!auction) return <p>Loading...</p>;
  return (
    <div>
      <h2>{auction.title}</h2>
      <p>{auction.description}</p>
      <p>Current Bid: ₹{auction.currentBid}</p>
      <div>
        <input value={bid} onChange={e => setBid(e.target.value)} placeholder="Enter amount" />
        <button onClick={placeBid}>Place Bid</button>
      </div>
      {msg && <p>{msg}</p>}
    </div>
  );
}
