import { useEffect, useState } from 'react';
import api from '../../lib/api';
import Link from 'next/link';

export default function Products() {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    api.get('/products').then(res => setProducts(res.data)).catch(console.error);
  }, []);
  return (
    <div>
      <h1>Products</h1>
      <ul>
        {products.map(p => (
          <li key={p.id}>
            <Link href={`/products/${p.id}`}>{p.name}</Link> — ₹{p.startingPrice}
          </li>
        ))}
      </ul>
    </div>
  );
}
