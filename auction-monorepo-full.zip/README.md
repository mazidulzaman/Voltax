# Auction Monorepo
Full starter for auction website (frontend + backend).